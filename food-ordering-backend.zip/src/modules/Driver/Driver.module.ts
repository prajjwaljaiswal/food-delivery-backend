// src/admin/admin.module.ts
import { Module } from '@nestjs/common';
import { DriverProfileModule } from './Profile-setup/driver-operation.module';
// import { DriverModule } from './driver/driver.module';
@Module({
    imports: [DriverProfileModule
    ],
})
export class DriverMainModule { }
