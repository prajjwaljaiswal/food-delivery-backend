// // src/common/utils/device-token.helper.ts
// export const buildDevicePayload = (dto, token) => ({
//   device_token: dto.device_token,
//   device_type: dto.device_type,
//   device_uuid: dto.device_uuid,
//   ip_address: dto.ip_address,
//   jwt_token: token,
// });
