// src/common/enums/roles.enum.ts
export enum RoleEnum {
  ADMIN = 1,
  RESTAURANT = 2,
  DRIVER = 3,
  USER = 4,
}
