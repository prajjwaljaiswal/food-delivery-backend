
export enum PaymentMethod {
  CARD = 'card',
  UPI = 'upi',
  COD = 'cod',
  WALLET = 'wallet',
}
